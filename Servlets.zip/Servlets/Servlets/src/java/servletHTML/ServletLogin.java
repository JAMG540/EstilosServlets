package servletHTML;

/**
 *
 * @author EMMANUEL
 */
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletLogin extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String user = req.getParameter("user");
		String pass = req.getParameter("password");
		if ("Molina".equals(user) && "hola".equals(pass)) {
			response(resp, "<br><br><br><center><B><font color='green' size='90'>¡logeo correcto!</font></B></center>");
		} else {
			response(resp, "<br><br><br><center><B><font color='red' size='90'>¡logeo incorrecto! e.e</font></B></center>");
		}
	}

	private void response(HttpServletResponse resp, String msg)
			throws IOException {
		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<t1>" + msg + "</t1>");
		out.println("</body>");
		out.println("</html>");
	}
}